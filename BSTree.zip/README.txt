
I implemented AVL Insertion and rebalancing, but I'm not sure that it works 100% of the time.